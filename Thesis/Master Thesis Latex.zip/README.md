# thesis_template

This package contains a tex template for writing the thesis.

You can see compiled PDFs here:
http://theses.pages.ais.uni-bonn.de/thesis_template

Original template by Max Schwarz.

The files need to be compiled using xelatex or lualatex.

